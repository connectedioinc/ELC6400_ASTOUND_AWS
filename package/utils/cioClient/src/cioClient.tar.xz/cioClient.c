/*cioClient - AWS MQTT Client*/

/* Standard includes. */
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <libubus.h>
#include <pthread.h>
#include <signal.h>
#include <net/if.h>
#include <sys/time.h>
/*Config settings*/
#include "cioClient_config.h"
/* MQTT API headers. */
#include "core_mqtt.h"
#include "core_mqtt_state.h"
/* OpenSSL sockets transport implementation. */
#include "openssl_posix.h"
/*Include backoff algorithm header for retry logic.*/
#include "backoff_algorithm.h"
/* Clock for timer. */
#include "clock.h"

pthread_mutex_t checkin_mutex = PTHREAD_MUTEX_INITIALIZER;

/*CIO Constants*/
#include "cio_defaults.h"

#include "utilities.h"
#include "provision.h"
#include "cjson/cJSON.h"
#include "mqtt_sync.h"
#include "ubus_json_compat.h"
#include "publish_utils.h"
#include "command_handler.h"

#ifndef BROKER_ENDPOINT
    #error "Please define an MQTT broker endpoint, BROKER_ENDPOINT, in cioClient_config.h."
#endif
#ifndef ROOT_CA_CERT_PATH
    #error "Please define path to Root CA certificate of the MQTT broker, ROOT_CA_CERT_PATH, in cioClient_config.h."
#endif
#ifndef CLIENT_IDENTIFIER
    #error "Please define a unique CLIENT_IDENTIFIER."
#endif

#ifndef BROKER_PORT
    #define BROKER_PORT    ( 8883 )
#endif

#ifndef NETWORK_BUFFER_SIZE
    #define NETWORK_BUFFER_SIZE    ( 1024U )
#endif

#define BROKER_ENDPOINT_LENGTH                   ( ( uint16_t ) ( sizeof( BROKER_ENDPOINT ) - 1 ) )
#define CLIENT_IDENTIFIER_LENGTH                 ( ( uint16_t ) ( sizeof( CLIENT_IDENTIFIER ) - 1 ) )
#define CONNECTION_RETRY_MAX_ATTEMPTS            ( 5U )
#define CONNECTION_RETRY_MAX_BACKOFF_DELAY_MS    ( 5000U )
#define CONNECTION_RETRY_BACKOFF_BASE_MS         ( 500U )
#define CONNACK_RECV_TIMEOUT_MS                  ( 1000U )
#define SUBSCRIBE_TOPIC_BASE                     "cio/device/DR/"
#define SUBSCRIBE_TOPIC_BASE_LENGTH              ( ( uint16_t ) ( sizeof( SUBSCRIBE_TOPIC_BASE ) - 1 ) )
#define PUBLISH_TOPIC_BASE                     	 "cio/device/DS/"
#define PUBLISH_TOPIC                       	 "cio/device/status"
#define PUBLISH_TOPIC_LENGTH                	( ( uint16_t ) ( sizeof( PUBLISH_TOPIC ) - 1 ) )
#define MQTT_EXAMPLE_MESSAGE                     "Hello World!"
#define MQTT_EXAMPLE_MESSAGE_LENGTH              ( ( uint16_t ) ( sizeof( MQTT_EXAMPLE_MESSAGE ) - 1 ) )
#define MAX_OUTGOING_PUBLISHES                   ( 5U )
#define MQTT_PACKET_ID_INVALID                   ( ( uint16_t ) 0U )
#define MQTT_PROCESS_LOOP_TIMEOUT_MS             ( 500U )
#define MQTT_KEEP_ALIVE_INTERVAL_SECONDS         ( 60U )
#define DEFAULT_CHECKIN         		 1800
#define DELAY_BETWEEN_PUBLISHES_SECONDS          ( 1U )
#define MQTT_PUBLISH_COUNT_PER_LOOP              ( 5U )
#define MQTT_SUBPUB_LOOP_DELAY_SECONDS           ( 5U )
#define TRANSPORT_SEND_RECV_TIMEOUT_MS           ( 8000 )
#define OUTGOING_PUBLISH_RECORD_LEN              ( 10U )
#define INCOMING_PUBLISH_RECORD_LEN              ( 10U )

#define LOG_LEVEL    LOG_DEBUG
#define ENABLE_MQTT_DEBUG_LOG 1
#include "logging_levels.h"
#include "logging_stack.h"

//Buffer for subscribe Topic
char g_subscribeTopic[TOPIC_MAX_LEN] = {0};
uint16_t g_subscribeTopic_length = 0;

char g_publishTopic[TOPIC_MAX_LEN] = {0};
uint16_t g_publishTopic_length = 0;

#define MQTT_RX_BUFFER_SIZE  16384
#define MQTT_TX_BUFFER_SIZE  16384
/* Static buffers for MQTT library */
static uint8_t mqttRxBuffer[MQTT_RX_BUFFER_SIZE];
static uint8_t mqttTxBuffer[MQTT_TX_BUFFER_SIZE];
/*Thread for monitors*/
pthread_t checkin_thread, thread_iface, thread_wifi, thread_eth;
pthread_mutex_t mqtt_mutex = PTHREAD_MUTEX_INITIALIZER;
volatile bool mqtt_connected = false;
/*Wifi Monitor Struct*/
static struct ubus_context *ctx_wifi = NULL;
//Keep-alive time
int g_mqtt_keepalive = MQTT_KEEP_ALIVE_INTERVAL_SECONDS; // default: 60 sec
//Check-in interval
int g_checkin_interval = DEFAULT_CHECKIN;              // default: 30 minutes
pthread_mutex_t mqtt_keepalive_mutex = PTHREAD_MUTEX_INITIALIZER;
// Optional flag to trigger reconnect
volatile int g_force_mqtt_reconnect = 0;

char g_aws_server[256] = BROKER_ENDPOINT;
char g_aws_template[64] = PROVISION_TEMPLATE_NAME;
//Time for ethernet port change to sustain
#define STABLE_TIME 30
#define DEBOUNCE_MS 2000
/*-----------------------------------------------------------*/

typedef struct PublishPackets
{
    /**
     * @brief Packet identifier of the publish packet.
     */
    uint16_t packetId;

    /**
     * @brief Publish info of the publish packet.
     */
    MQTTPublishInfo_t pubInfo;
} PublishPackets_t;

/*-----------------------------------------------------------*/

static uint16_t globalAckPacketIdentifier = 0U;
static uint16_t globalSubscribePacketIdentifier = 0U;
static uint16_t globalUnsubscribePacketIdentifier = 0U;
static PublishPackets_t outgoingPublishPackets[ MAX_OUTGOING_PUBLISHES ] = { 0 };
static MQTTSubscribeInfo_t pGlobalSubscriptionList[ 1 ];
static uint8_t buffer[ NETWORK_BUFFER_SIZE ];
static MQTTSubAckStatus_t globalSubAckStatus = MQTTSubAckFailure;
static MQTTPubAckInfo_t pOutgoingPublishRecords[ OUTGOING_PUBLISH_RECORD_LEN ];
static MQTTPubAckInfo_t pIncomingPublishRecords[ INCOMING_PUBLISH_RECORD_LEN ];

/*-----------------------------------------------------------*/

/* Each compilation unit must define the NetworkContext struct. */
struct NetworkContext
{
    OpensslParams_t * pParams;
};

typedef struct {
    struct ubus_event_handler handler;   // must be first
    MQTTContext_t *mqttContext;
    const char *imei;
    const char *topic;
} WifiHandlerCtx;


typedef struct {
    MQTTContext_t *mqttContext;
    const char *imei;
    const char *topic;
} ThreadArgs;
//Wifi event handler data holder
typedef struct {
    MQTTContext_t *mqttContext;
    const char *imei;
    const char *topic;
} WifiEventArgs;

static uint32_t generateRandomNumber();

static int connectToServerWithBackoffRetries( NetworkContext_t * pNetworkContext,
                                              MQTTContext_t * pMqttContext,
                                              bool * pClientSessionPresent,
                                              bool * pBrokerSessionPresent, const char *imei );
static int subscribePublishLoop( MQTTContext_t * pMqttContext );
static void handleIncomingPublish( MQTTContext_t * pMqttContext, MQTTPublishInfo_t * pPublishInfo,
                                   uint16_t packetIdentifier );
static void eventCallback( MQTTContext_t * pMqttContext,
                           MQTTPacketInfo_t * pPacketInfo,
                           MQTTDeserializedInfo_t * pDeserializedInfo );
static int initializeMqtt( MQTTContext_t * pMqttContext,
                           NetworkContext_t * pNetworkContext );

static int establishMqttSession( MQTTContext_t * pMqttContext, NetworkContext_t * pNetworkContext,
                                 bool createCleanSession,
                                 bool * pSessionPresent, const char *imei );

static int disconnectMqttSession( MQTTContext_t * pMqttContext );
static int subscribeToTopic( MQTTContext_t * pMqttContext );
static int unsubscribeFromTopic( MQTTContext_t * pMqttContext );
static int publishToTopic( MQTTContext_t * pMqttContext );
static int getNextFreeIndexForOutgoingPublishes( uint8_t * pIndex );
static void cleanupOutgoingPublishAt( uint8_t index );
static void cleanupOutgoingPublishes( void );
static void cleanupOutgoingPublishWithPacketID( uint16_t packetId );
static int handlePublishResend( MQTTContext_t * pMqttContext );
static void updateSubAckStatus( MQTTPacketInfo_t * pPacketInfo );
static int handleResubscribe( MQTTContext_t * pMqttContext );
static int waitForPacketAck( MQTTContext_t * pMqttContext,
                             uint16_t usPacketIdentifier,
                             uint32_t ulTimeout );
static MQTTStatus_t processLoopWithTimeout( MQTTContext_t * pMqttContext,
                                            uint32_t ulTimeoutMs );

/*-----------------------------------------------------------*/

static uint32_t generateRandomNumber()
{
    return( rand() );
}

/*-----------------------------------------------------------*/
static int connectToServerWithBackoffRetries( NetworkContext_t * pNetworkContext,
                                              MQTTContext_t * pMqttContext,
                                              bool * pClientSessionPresent,
                                              bool * pBrokerSessionPresent, const char *imei )
{
    int returnStatus = EXIT_FAILURE;
    BackoffAlgorithmStatus_t backoffAlgStatus = BackoffAlgorithmSuccess;
    OpensslStatus_t opensslStatus = OPENSSL_SUCCESS;
    BackoffAlgorithmContext_t reconnectParams;
    ServerInfo_t serverInfo;
    OpensslCredentials_t opensslCredentials;
    uint16_t nextRetryBackOff;
    bool createCleanSession;

    /* Initialize information to connect to the MQTT broker. */
    serverInfo.pHostName = g_aws_server;
    serverInfo.hostNameLength = get_broker_endpoint_length();
    serverInfo.port = BROKER_PORT;

    /* Initialize credentials for establishing TLS session. */
    memset( &opensslCredentials, 0, sizeof( OpensslCredentials_t ) );
    opensslCredentials.pRootCaPath = ROOT_CA_CERT_PATH;
	opensslCredentials.pClientCertPath = DEVICE_CERT_PATH;
	opensslCredentials.pPrivateKeyPath = DEVICE_KEY_PATH;    
    opensslCredentials.sniHostName = g_aws_server;

    /* Initialize reconnect attempts and interval */
    BackoffAlgorithm_InitializeParams( &reconnectParams,
                                       CONNECTION_RETRY_BACKOFF_BASE_MS,
                                       CONNECTION_RETRY_MAX_BACKOFF_DELAY_MS,
                                       CONNECTION_RETRY_MAX_ATTEMPTS );

    /* Attempt to connect to MQTT broker. If connection fails, retry after
     * a timeout. Timeout value will exponentially increase till maximum
     * attempts are reached.
     */
    do
    {
        /* Establish a TLS session with the MQTT broker. This example connects
         * to the MQTT broker as specified in BROKER_ENDPOINT and BROKER_PORT at
         * the top of this file. */
        log_message( "INFO", "Establishing a TLS session to %.*s:%d.",
                   get_broker_endpoint_length(),
                   g_aws_server,
                   BROKER_PORT  );
        opensslStatus = Openssl_Connect( pNetworkContext,
                                         &serverInfo,
                                         &opensslCredentials,
                                         TRANSPORT_SEND_RECV_TIMEOUT_MS,
                                         TRANSPORT_SEND_RECV_TIMEOUT_MS );

        if( opensslStatus == OPENSSL_SUCCESS )
        {
            /* A clean MQTT session needs to be created, if there is no session saved
             * in this MQTT client. */
            createCleanSession = ( *pClientSessionPresent == true ) ? false : true;

            /* Sends an MQTT Connect packet using the established TLS session,
             * then waits for connection acknowledgment (CONNACK) packet. */
            //returnStatus = establishMqttSession( pMqttContext, createCleanSession, pBrokerSessionPresent, imei );
            returnStatus = establishMqttSession( pMqttContext, pNetworkContext, createCleanSession, pBrokerSessionPresent, imei );
            
            if( returnStatus == EXIT_FAILURE )
            {
                /* End TLS session, then close TCP connection. */
                ( void ) Openssl_Disconnect( pNetworkContext );
            }
        }

        if( returnStatus == EXIT_FAILURE )
        {
            /* Generate a random number and get back-off value (in milliseconds) for the next connection retry. */
            backoffAlgStatus = BackoffAlgorithm_GetNextBackoff( &reconnectParams, generateRandomNumber(), &nextRetryBackOff );

            if( backoffAlgStatus == BackoffAlgorithmRetriesExhausted )
            {
                log_message( "ERROR", "Connection to the broker failed, all attempts exhausted" );
                returnStatus = EXIT_FAILURE;
            }
            else if( backoffAlgStatus == BackoffAlgorithmSuccess )
            {
               log_message( "DEBUG", "Connection to the broker failed. Retrying connection "
                           "after %hu ms backoff.",
                           ( unsigned short ) nextRetryBackOff  );
                Clock_SleepMs( nextRetryBackOff );
            }
        }
    } while( ( returnStatus == EXIT_FAILURE ) && ( backoffAlgStatus == BackoffAlgorithmSuccess ) );

    return returnStatus;
}

/*-----------------------------------------------------------*/

static int getNextFreeIndexForOutgoingPublishes( uint8_t * pIndex )
{
    int returnStatus = EXIT_FAILURE;
    uint8_t index = 0;

    assert( outgoingPublishPackets != NULL );
    assert( pIndex != NULL );

    for( index = 0; index < MAX_OUTGOING_PUBLISHES; index++ )
    {
        /* A free index is marked by invalid packet id.
         * Check if the the index has a free slot. */
        if( outgoingPublishPackets[ index ].packetId == MQTT_PACKET_ID_INVALID )
        {
            returnStatus = EXIT_SUCCESS;

            /* Copy the available index into the output param. */
            *pIndex = index;

            break;
        }
    }

    /* Copy the available index into the output param. */
    *pIndex = index;

    return returnStatus;
}
/*-----------------------------------------------------------*/

static void cleanupOutgoingPublishAt( uint8_t index )
{
    assert( outgoingPublishPackets != NULL );
    assert( index < MAX_OUTGOING_PUBLISHES );

    /* Clear the outgoing publish packet. */
    ( void ) memset( &( outgoingPublishPackets[ index ] ),
                     0x00,
                     sizeof( outgoingPublishPackets[ index ] ) );
}

/*-----------------------------------------------------------*/

static void cleanupOutgoingPublishes( void )
{
    assert( outgoingPublishPackets != NULL );

    /* Clean up all the outgoing publish packets. */
    ( void ) memset( outgoingPublishPackets, 0x00, sizeof( outgoingPublishPackets ) );
}

/*-----------------------------------------------------------*/

static void cleanupOutgoingPublishWithPacketID( uint16_t packetId )
{
    uint8_t index = 0;

    assert( outgoingPublishPackets != NULL );
    assert( packetId != MQTT_PACKET_ID_INVALID );

    /* Clean up all the saved outgoing publishes. */
    for( ; index < MAX_OUTGOING_PUBLISHES; index++ )
    {
        if( outgoingPublishPackets[ index ].packetId == packetId )
        {
            cleanupOutgoingPublishAt( index );
            log_message("INFO",  "Cleaned up outgoing publish packet with packet id %u",
                       packetId  );
            break;
        }
    }
}

/*-----------------------------------------------------------*/

static int handlePublishResend( MQTTContext_t * pMqttContext )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus = MQTTSuccess;
    uint8_t index = 0U;
    MQTTStateCursor_t cursor = MQTT_STATE_CURSOR_INITIALIZER;
    uint16_t packetIdToResend = MQTT_PACKET_ID_INVALID;
    bool foundPacketId = false;

    assert( pMqttContext != NULL );
    assert( outgoingPublishPackets != NULL );

    /* MQTT_PublishToResend() provides a packet ID of the next PUBLISH packet
     * that should be resent. In accordance with the MQTT v3.1.1 spec,
     * MQTT_PublishToResend() preserves the ordering of when the original
     * PUBLISH packets were sent. The outgoingPublishPackets array is searched
     * through for the associated packet ID. If the application requires
     * increased efficiency in the look up of the packet ID, then a hashmap of
     * packetId key and PublishPacket_t values may be used instead. */
    packetIdToResend = MQTT_PublishToResend( pMqttContext, &cursor );

    while( packetIdToResend != MQTT_PACKET_ID_INVALID )
    {
        foundPacketId = false;

        for( index = 0U; index < MAX_OUTGOING_PUBLISHES; index++ )
        {
            if( outgoingPublishPackets[ index ].packetId == packetIdToResend )
            {
                foundPacketId = true;
                outgoingPublishPackets[ index ].pubInfo.dup = true;

                log_message("INFO",  "Sending duplicate PUBLISH with packet id %u",
                           outgoingPublishPackets[ index ].packetId  );
                mqttStatus = MQTT_Publish( pMqttContext,
                                           &outgoingPublishPackets[ index ].pubInfo,
                                           outgoingPublishPackets[ index ].packetId );

                if( mqttStatus != MQTTSuccess )
                {
                    log_message( "ERROR", "Sending duplicate PUBLISH for packet id %u "
                                " failed with status %s",
                                outgoingPublishPackets[ index ].packetId,
                                MQTT_Status_strerror( mqttStatus )  );
                    returnStatus = EXIT_FAILURE;
                    break;
                }
                else
                {
                    log_message( "INFO", "Sent duplicate PUBLISH successfully for packet id %u",
                               outgoingPublishPackets[ index ].packetId  );
                }
            }
        }

        if( foundPacketId == false )
        {
           log_message( "ERROR", "Packet id %u requires resend, but was not found in "
                        "outgoingPublishPackets",
                        packetIdToResend  );
            returnStatus = EXIT_FAILURE;
            break;
        }
        else
        {
            /* Get the next packetID to be resent. */
            packetIdToResend = MQTT_PublishToResend( pMqttContext, &cursor );
        }
    }

    return returnStatus;
}

/*-----------------------------------------------------------*/

static void handleIncomingPublish( MQTTContext_t * pMqttContext, MQTTPublishInfo_t * pPublishInfo,
                                   uint16_t packetIdentifier )
{
    assert( pPublishInfo != NULL );

    ( void ) packetIdentifier;

    /* Process incoming Publish. */
    log_message( "INFO", "Incoming QOS : %d", pPublishInfo->qos );

    /* Verify the received publish is for the topic we have subscribed to. */
    if( ( pPublishInfo->topicNameLength == g_subscribeTopic_length ) &&
        ( 0 == strncmp( g_subscribeTopic,
                        pPublishInfo->pTopicName,
                        pPublishInfo->topicNameLength ) ) )
    {
        /*log_message( "INFO", "Incoming Publish Topic Name: %.*s matches subscribed topic.\n"
                   "Incoming Publish message Packet Id is %u.\n"
                   "Incoming Publish Message : %.*s",
                   pPublishInfo->topicNameLength,
                   pPublishInfo->pTopicName,
                   packetIdentifier,
                   ( int ) pPublishInfo->payloadLength,
                   ( const char * ) pPublishInfo->pPayload  );
                   
		const char *topic = pPublishInfo->pTopicName;
		size_t topicLen = pPublishInfo->topicNameLength;
		char topicBuf[256];
		if (topicLen >= sizeof(topicBuf)) topicLen = sizeof(topicBuf)-1;
		memcpy(topicBuf, topic, topicLen); topicBuf[topicLen] = '\0';

		const char *payload = (const char*)pPublishInfo->pPayload;
		size_t payloadLen = pPublishInfo->payloadLength;

		char *payloadCopy = malloc(payloadLen+1);
		memcpy(payloadCopy, payload, payloadLen);
		payloadCopy[payloadLen] = '\0';

		if (strcmp(topicBuf, CREATE_CERT_ACCEPTED) == 0) {
			log_message("INFO", "Received CreateKeysAndCertificate: %s", payloadCopy);

			cJSON *root = cJSON_Parse(payloadCopy);
		if (root) {
	    		cJSON *cert = cJSON_GetObjectItem(root, "certificatePem");
	    		cJSON *keyPair = cJSON_GetObjectItem(root, "keyPair");
	    		cJSON *priv = keyPair ? cJSON_GetObjectItem(keyPair, "PrivateKey") : NULL;
	    		cJSON *ownership = cJSON_GetObjectItem(root, "certificateOwnershipToken");

	    		if (cert && priv && ownership) {
				save_file_secure("/tmp/new_cert.pem", cert->valuestring);
				save_file_secure("/tmp/new_key.key", priv->valuestring);
				save_file_secure("/tmp/ownership_token.txt", ownership->valuestring);
	    		}
	    		cJSON_Delete(root);
		}
		}
	else if (strstr(topicBuf, "provision/json/accepted")) {
		log_message("INFO", "Provisioning accepted: %s", payloadCopy);
		cJSON *root = cJSON_Parse(payloadCopy);
		if (root) {
	    	cJSON *cert = cJSON_GetObjectItem(root, "certificatePem");
	    	cJSON *priv = cJSON_GetObjectItem(root, "privateKey");
	    	if (cert && priv) {
			save_file_secure(DEVICE_CERT_PATH, cert->valuestring);
			save_file_secure(DEVICE_KEY_PATH, priv->valuestring);
	    	} else {
			char *tmpCert = read_file("/tmp/new_cert.pem");
			char *tmpKey = read_file("/tmp/new_key.key");
			if (tmpCert && tmpKey) {
		    		save_file_secure(DEVICE_CERT_PATH, tmpCert);
		    		save_file_secure(DEVICE_KEY_PATH, tmpKey);
			}
			free(tmpCert); 
			free(tmpKey);
	    	}
	    	cJSON_Delete(root);
		}
	}
	else if (strstr(topicBuf, "provision/json/rejected")) {
		log_message("ERROR", "Provisioning rejected: %s", payloadCopy);
	}
	free(payloadCopy);*/
	// --- inside your MQTT message callback ---
	const MQTTPublishInfo_t *pub = pPublishInfo;
	if (!pub || !pub->pPayload) return;

	char topic[256];
	snprintf(topic, sizeof(topic), "%.*s",
		 (int)pub->topicNameLength, pub->pTopicName);

	char rawMsg[2048];
	snprintf(rawMsg, sizeof(rawMsg), "%.*s",
		 (int)pub->payloadLength, (const char *)pub->pPayload);
	trim(rawMsg);

	log_message("INFO", "Received message topic=%s payload=%s", topic, rawMsg);

	/* ---- Step 1: Parse JSON from AWS IoT ---- */
	cJSON *root = cJSON_Parse(rawMsg);
	if (!root)
	{
	    log_message("ERROR", "Invalid JSON received: %s", rawMsg);
	    return;
	}

	cJSON *payloadItem = cJSON_GetObjectItemCaseSensitive(root, "payload");
	if (!cJSON_IsString(payloadItem) || payloadItem->valuestring == NULL)
	{
	    log_message("ERROR", "Missing or invalid 'payload' field");
	    cJSON_Delete(root);
	    return;
	}

	/* ---- Step 2: Extract the actual command payload ---- */
	const char *payloadStr = payloadItem->valuestring;
	log_message("INFO", "Inner command payload: %s", payloadStr);

	/* ---- Step 3: Tokenize CSV-style command ---- */
	ServerCommand cmd = {0};
	char payloadCopy[1024];
	strncpy(payloadCopy, payloadStr, sizeof(payloadCopy) - 1);

	char *saveptr = NULL;
	char *token = strtok_r(payloadCopy, ",", &saveptr);
	int index = 0;
	while (token && index < (2 + MAX_CMD_PARAMS))
	{
	    trim(token);
	    if (strcmp(token, "NA") != 0 && strlen(token) > 0)
	    {
		if (index == 0)
		    strncpy(cmd.notificationID, token, sizeof(cmd.notificationID) - 1);
		else if (index == 1)
		    strncpy(cmd.commandType, token, sizeof(cmd.commandType) - 1);
		else if (index >= 2)
		    strncpy(cmd.params[index - 2], token, sizeof(cmd.params[0]) - 1);
	    }
	    token = strtok_r(NULL, ",", &saveptr);
	    index++;
	}
	cmd.paramCount = (index > 2) ? (index - 2) : 0;

	log_message("INFO", "Parsed commandType=%s notificationID=%s paramCount=%d",
		    cmd.commandType, cmd.notificationID, cmd.paramCount);

	cJSON_Delete(root);

	/* ---- Step 4: Dispatch to handler ---- */
	handle_server_command(pMqttContext, &cmd);
    }
    else
    {
        log_message( "INFO", "Incoming Publish Topic Name: %.*s does not match subscribed topic",
                   pPublishInfo->topicNameLength,
                   pPublishInfo->pTopicName  );
    }
}

/*-----------------------------------------------------------*/

static void updateSubAckStatus( MQTTPacketInfo_t * pPacketInfo )
{
    uint8_t * pPayload = NULL;
    size_t pSize = 0;

    MQTTStatus_t mqttStatus = MQTT_GetSubAckStatusCodes( pPacketInfo, &pPayload, &pSize );

    /* MQTT_GetSubAckStatusCodes always returns success if called with packet info
     * from the event callback and non-NULL parameters. */
    assert( mqttStatus == MQTTSuccess );

    /* Suppress unused variable warning when asserts are disabled in build. */
    ( void ) mqttStatus;

    /* Demo only subscribes to one topic, so only one status code is returned. */
    globalSubAckStatus = ( MQTTSubAckStatus_t ) pPayload[ 0 ];
}

/*-----------------------------------------------------------*/

static int handleResubscribe( MQTTContext_t * pMqttContext )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus = MQTTSuccess;
    BackoffAlgorithmStatus_t backoffAlgStatus = BackoffAlgorithmSuccess;
    BackoffAlgorithmContext_t retryParams;
    uint16_t nextRetryBackOff = 0U;

    assert( pMqttContext != NULL );

    /* Initialize retry attempts and interval. */
    BackoffAlgorithm_InitializeParams( &retryParams,
                                       CONNECTION_RETRY_BACKOFF_BASE_MS,
                                       CONNECTION_RETRY_MAX_BACKOFF_DELAY_MS,
                                       CONNECTION_RETRY_MAX_ATTEMPTS );

    do
    {
        /* Send SUBSCRIBE packet.
         * Note: reusing the value specified in globalSubscribePacketIdentifier is acceptable here
         * because this function is entered only after the receipt of a SUBACK, at which point
         * its associated packet id is free to use. */
        mqttStatus = MQTT_Subscribe( pMqttContext,
                                     pGlobalSubscriptionList,
                                     sizeof( pGlobalSubscriptionList ) / sizeof( MQTTSubscribeInfo_t ),
                                     globalSubscribePacketIdentifier );

        if( mqttStatus != MQTTSuccess )
        {
            log_message( "ERROR", "Failed to send SUBSCRIBE packet to broker with error = %s",
                        MQTT_Status_strerror( mqttStatus )  );
            returnStatus = EXIT_FAILURE;
            break;
        }

        log_message( "INFO", "SUBSCRIBE sent for topic %.*s to broker",
                   g_subscribeTopic_length,
                   g_subscribeTopic  );

        /* Process incoming packet. */
        returnStatus = waitForPacketAck( pMqttContext,
                                         globalSubscribePacketIdentifier,
                                         MQTT_PROCESS_LOOP_TIMEOUT_MS );

        if( returnStatus == EXIT_FAILURE )
        {
            break;
        }

        /* Check if recent subscription request has been rejected. globalSubAckStatus is updated
         * in eventCallback to reflect the status of the SUBACK sent by the broker. It represents
         * either the QoS level granted by the server upon subscription, or acknowledgement of
         * server rejection of the subscription request. */
        if( globalSubAckStatus == MQTTSubAckFailure )
        {
            /* Generate a random number and get back-off value (in milliseconds) for the next re-subscribe attempt. */
            backoffAlgStatus = BackoffAlgorithm_GetNextBackoff( &retryParams, generateRandomNumber(), &nextRetryBackOff );

            if( backoffAlgStatus == BackoffAlgorithmRetriesExhausted )
            {
                log_message( "ERROR", "Server rejected subscription request, all attempts exhausted"  );
                returnStatus = EXIT_FAILURE;
            }
            else if( backoffAlgStatus == BackoffAlgorithmSuccess )
            {
                log_message( "DEBUG","Server rejected subscription request. Retrying "
                           "connection after %hu ms backoff",
                           ( unsigned short ) nextRetryBackOff  );
                Clock_SleepMs( nextRetryBackOff );
            }
        }
    } while( ( globalSubAckStatus == MQTTSubAckFailure ) && ( backoffAlgStatus == BackoffAlgorithmSuccess ) );

    return returnStatus;
}

/*-----------------------------------------------------------*/

static void eventCallback( MQTTContext_t * pMqttContext,
                           MQTTPacketInfo_t * pPacketInfo,
                           MQTTDeserializedInfo_t * pDeserializedInfo )
{
    uint16_t packetIdentifier;

    assert( pMqttContext != NULL );
    assert( pPacketInfo != NULL );
    assert( pDeserializedInfo != NULL );

    /* Suppress unused parameter warning when asserts are disabled in build. */
    ( void ) pMqttContext;

    packetIdentifier = pDeserializedInfo->packetIdentifier;

    /* Handle incoming publish. The lower 4 bits of the publish packet
     * type is used for the dup, QoS, and retain flags. Hence masking
     * out the lower bits to check if the packet is publish. */
    if( ( pPacketInfo->type & 0xF0U ) == MQTT_PACKET_TYPE_PUBLISH )
    {
        assert( pDeserializedInfo->pPublishInfo != NULL );
        /* Handle incoming publish. */
        handleIncomingPublish( pMqttContext, pDeserializedInfo->pPublishInfo, packetIdentifier );
    }
    else
    {
        /* Handle other packets. */
        switch( pPacketInfo->type )
        {
            case MQTT_PACKET_TYPE_SUBACK:

                /* A SUBACK from the broker, containing the server response to our subscription request, has been received.
                 * It contains the status code indicating server approval/rejection for the subscription to the single topic
                 * requested. The SUBACK will be parsed to obtain the status code, and this status code will be stored in global
                 * variable globalSubAckStatus. */
                updateSubAckStatus( pPacketInfo );

                /* Check status of the subscription request. If globalSubAckStatus does not indicate
                 * server refusal of the request (MQTTSubAckFailure), it contains the QoS level granted
                 * by the server, indicating a successful subscription attempt. */
                if( globalSubAckStatus != MQTTSubAckFailure )
                {
                    log_message("INFO",  "Subscribed to the topic %.*s. with maximum QoS %u",
                               g_subscribeTopic_length,
                               g_subscribeTopic,
                               globalSubAckStatus  );
                }

                /* Make sure ACK packet identifier matches with Request packet identifier. */
                assert( globalSubscribePacketIdentifier == packetIdentifier );

                /* Update the global ACK packet identifier. */
                globalAckPacketIdentifier = packetIdentifier;
                break;

            case MQTT_PACKET_TYPE_UNSUBACK:
                log_message( "INFO", "Unsubscribed from the topic %.*s",
                           g_subscribeTopic_length,
                           g_subscribeTopic  );
                /* Make sure ACK packet identifier matches with Request packet identifier. */
                assert( globalUnsubscribePacketIdentifier == packetIdentifier );

                /* Update the global ACK packet identifier. */
                globalAckPacketIdentifier = packetIdentifier;
                break;

            case MQTT_PACKET_TYPE_PINGRESP:

                /* Nothing to be done from application as library handles
                 * PINGRESP. */
                log_message( "DEBUG", "PINGRESP should not be handled by the application "
                           "callback when using MQTT_ProcessLoop"  );
                break;

            case MQTT_PACKET_TYPE_PUBREC:
                log_message( "INFO", "PUBREC received for packet id %u",
                           packetIdentifier  );
                /* Cleanup publish packet when a PUBREC is received. */
                cleanupOutgoingPublishWithPacketID( packetIdentifier );
                break;

            case MQTT_PACKET_TYPE_PUBREL:

                /* Nothing to be done from application as library handles
                 * PUBREL. */
                log_message( "INFO", "PUBREL received for packet id %u",
                           packetIdentifier  );
                break;

            case MQTT_PACKET_TYPE_PUBCOMP:

                /* Nothing to be done from application as library handles
                 * PUBCOMP. */
                log_message( "INFO", "PUBCOMP received for packet id %u",
                           packetIdentifier  );
                break;

	    case MQTT_PACKET_TYPE_PUBACK:
    		log_message("INFO", "PUBACK received (QoS1 acknowledgment).");
    		break;
    		
            /* Any other packet type is invalid. */
            default:
                log_message( "ERROR","Unknown packet type received:(%02x)",
                            pPacketInfo->type  );
        }
    }
}

/*-----------------------------------------------------------*/

//static int establishMqttSession( MQTTContext_t * pMqttContext,
//                                 bool createCleanSession,
//                                 bool * pSessionPresent, const char *imei )
//{
//    int returnStatus = EXIT_SUCCESS;
//    MQTTStatus_t mqttStatus;
//    MQTTConnectInfo_t connectInfo;
//    MQTTPublishInfo_t willInfo = { 0 };
    /* Establish MQTT session by sending a CONNECT packet. */

    /* If #createCleanSession is true, start with a clean session
     * i.e. direct the MQTT broker to discard any previous session data.
     * If #createCleanSession is false, directs the broker to attempt to
     * reestablish a session which was already present. */
//    connectInfo.cleanSession = createCleanSession;

    /* The client identifier is used to uniquely identify this MQTT client to
     * the MQTT broker. In a production device the identifier can be something
     * unique, such as a device serial number. */
//    connectInfo.pClientIdentifier = clientIdentifier;
//    connectInfo.clientIdentifierLength = (uint16_t)clientIdentifierLength;

    /* The maximum time interval in seconds which is allowed to elapse
     * between two Control Packets.
     * It is the responsibility of the Client to ensure that the interval between
     * Control Packets being sent does not exceed the this Keep Alive value. In the
     * absence of sending any other Control Packets, the Client MUST send a
     * PINGREQ Packet. */
//    pthread_mutex_lock(&mqtt_keepalive_mutex);     
//    connectInfo.keepAliveSeconds = g_mqtt_keepalive;
//    pthread_mutex_unlock(&mqtt_keepalive_mutex);

    /* Username and password for authentication. Not used in this demo. */
//    connectInfo.pUserName = NULL;
//    connectInfo.userNameLength = 0U;
//    connectInfo.pPassword = NULL;
//    connectInfo.passwordLength = 0U;

//    char strWillPayload[128];
//    snprintf(strWillPayload, sizeof(strWillPayload), "{\"A\":{\"a\":\"%s\",\"b\":\"0\"}}", imei);       
    /* Fill in Will structure */
//    willInfo.pTopicName = PUBLISH_TOPIC;
//    willInfo.topicNameLength = (uint16_t)strlen(PUBLISH_TOPIC);
//    willInfo.pPayload = strWillPayload;
//    willInfo.payloadLength = (uint16_t)strlen(strWillPayload);
//    willInfo.qos = MQTTQoS1;
    
    /* Send MQTT CONNECT packet to broker. */
//    mqttStatus = MQTT_Connect( pMqttContext, &connectInfo, &willInfo, CONNACK_RECV_TIMEOUT_MS, pSessionPresent );

//    if( mqttStatus != MQTTSuccess )
//    {
//        returnStatus = EXIT_FAILURE;
//       log_message( "ERROR", "Connection with MQTT broker failed with status %s",
//                    MQTT_Status_strerror( mqttStatus ) );
//    }
//    else
//    {
//        log_message(  "INFO","MQTT connection successfully established with broker"  );
//    }

//    return returnStatus;
//}

static int establishMqttSession( MQTTContext_t * pMqttContext,
                                 NetworkContext_t * pNetworkContext,
                                 bool createCleanSession,
                                 bool * pSessionPresent,
                                 const char *imei )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus;
    MQTTConnectInfo_t connectInfo = { 0 };
    MQTTPublishInfo_t willInfo = { 0 };

    /* --- 1. Ensure previous disconnect or state cleanup --- */
    if( pMqttContext != NULL )
    {
        if( pMqttContext->connectStatus != MQTTNotConnected )
        {
            log_message("WARN", "Previous MQTT state not fully closed. Forcing disconnect before new connect.");
            ( void ) MQTT_Disconnect( pMqttContext );
            /* Close TLS connection */
            Openssl_Disconnect( pNetworkContext );
            usleep( 500 * 1000 );  /* 500 ms delay */
        }
    }

    /* --- 2. Prepare connection info --- */
    connectInfo.cleanSession = createCleanSession;
    connectInfo.pClientIdentifier = clientIdentifier;
    connectInfo.clientIdentifierLength = (uint16_t) clientIdentifierLength;

    pthread_mutex_lock( &mqtt_keepalive_mutex );
    connectInfo.keepAliveSeconds = g_mqtt_keepalive;
    pthread_mutex_unlock( &mqtt_keepalive_mutex );

    connectInfo.pUserName = NULL;
    connectInfo.userNameLength = 0U;
    connectInfo.pPassword = NULL;
    connectInfo.passwordLength = 0U;

    /* --- 3. Build the Will payload --- */
    char strWillPayload[128];
    snprintf( strWillPayload, sizeof( strWillPayload ),
              "{\"A\":{\"a\":\"%s\",\"b\":\"0\"}}", imei );

    willInfo.pTopicName = PUBLISH_TOPIC;
    willInfo.topicNameLength = (uint16_t) strlen( PUBLISH_TOPIC );
    willInfo.pPayload = strWillPayload;
    willInfo.payloadLength = (uint16_t) strlen( strWillPayload );
    willInfo.qos = MQTTQoS1;

    /* --- 4. Attempt connection --- */
    log_message( "INFO", "Establishing a TLS session to %s:%d.",
                 g_aws_server, BROKER_PORT );

    mqttStatus = MQTT_Connect( pMqttContext,
                               &connectInfo,
                               &willInfo,
                               CONNACK_RECV_TIMEOUT_MS,
                               pSessionPresent );

    if( mqttStatus != MQTTSuccess )
    {
        log_message( "ERROR", "Connection with MQTT broker failed with status %s",
                     MQTT_Status_strerror( mqttStatus ) );

        /* --- 5. Perform cleanup and delay before retry --- */
        ( void ) MQTT_Disconnect( pMqttContext );
        Openssl_Disconnect( pNetworkContext );   // Proper network cleanup for your setup
        usleep( 1000 * 1000 );  /* 1 second backoff */

        returnStatus = EXIT_FAILURE;
    }
    else
    {
        log_message( "INFO", "MQTT connection successfully established with broker" );
    }

    return returnStatus;
}



/*-----------------------------------------------------------*/

static int disconnectMqttSession( MQTTContext_t * pMqttContext )
{
    MQTTStatus_t mqttStatus = MQTTSuccess;
    int returnStatus = EXIT_SUCCESS;

    assert( pMqttContext != NULL );

    /* Send DISCONNECT. */
    mqttStatus = MQTT_Disconnect( pMqttContext );

    if( mqttStatus != MQTTSuccess )
    {
        log_message( "ERROR", "Sending MQTT DISCONNECT failed with status=%s",
                    MQTT_Status_strerror( mqttStatus )  );
        returnStatus = EXIT_FAILURE;
    }

    return returnStatus;
}

/*-----------------------------------------------------------*/

static int subscribeToTopic( MQTTContext_t * pMqttContext )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus;

    assert( pMqttContext != NULL );

    /* Start with everything at 0. */
    ( void ) memset( ( void * ) pGlobalSubscriptionList, 0x00, sizeof( pGlobalSubscriptionList ) );

    /* This example subscribes to only one topic and uses QOS0. */
    pGlobalSubscriptionList[ 0 ].qos = MQTTQoS1;
    pGlobalSubscriptionList[ 0 ].pTopicFilter = g_subscribeTopic;
    pGlobalSubscriptionList[ 0 ].topicFilterLength = g_subscribeTopic_length;

    /* Generate packet identifier for the SUBSCRIBE packet. */
    globalSubscribePacketIdentifier = MQTT_GetPacketId( pMqttContext );

    /* Send SUBSCRIBE packet. */
    mqttStatus = MQTT_Subscribe( pMqttContext,
                                 pGlobalSubscriptionList,
                                 sizeof( pGlobalSubscriptionList ) / sizeof( MQTTSubscribeInfo_t ),
                                 globalSubscribePacketIdentifier );

    if( mqttStatus != MQTTSuccess )
    {
        log_message( "ERROR", "Failed to send SUBSCRIBE packet to broker with error = %s",
                    MQTT_Status_strerror( mqttStatus )  );
        returnStatus = EXIT_FAILURE;
    }
    else
    {
        log_message( "INFO", "SUBSCRIBE sent for topic %.*s to broker",
                   g_subscribeTopic_length,
                   g_subscribeTopic  );
    }

    return returnStatus;
}

/*-----------------------------------------------------------*/

static int unsubscribeFromTopic( MQTTContext_t * pMqttContext )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus;

    assert( pMqttContext != NULL );

    /* Start with everything at 0. */
    ( void ) memset( ( void * ) pGlobalSubscriptionList, 0x00, sizeof( pGlobalSubscriptionList ) );

    /* This example subscribes to and unsubscribes from only one topic
     * and uses QOS2. */
    pGlobalSubscriptionList[ 0 ].qos = MQTTQoS0;
    pGlobalSubscriptionList[ 0 ].pTopicFilter = g_subscribeTopic;
    pGlobalSubscriptionList[ 0 ].topicFilterLength = g_subscribeTopic_length;

    /* Generate packet identifier for the UNSUBSCRIBE packet. */
    globalUnsubscribePacketIdentifier = MQTT_GetPacketId( pMqttContext );

    /* Send UNSUBSCRIBE packet. */
    mqttStatus = MQTT_Unsubscribe( pMqttContext,
                                   pGlobalSubscriptionList,
                                   sizeof( pGlobalSubscriptionList ) / sizeof( MQTTSubscribeInfo_t ),
                                   globalUnsubscribePacketIdentifier );

    if( mqttStatus != MQTTSuccess )
    {
        log_message( "ERROR", "Failed to send UNSUBSCRIBE packet to broker with error = %s",
                    MQTT_Status_strerror( mqttStatus )  );
        returnStatus = EXIT_FAILURE;
    }
    else
    {
        log_message( "INFO", "UNSUBSCRIBE sent for topic %.*s to broker",
                   g_subscribeTopic_length,
                   g_subscribeTopic  );
    }

    return returnStatus;
}

/*-----------------------------------------------------------*/

static int publishToTopic( MQTTContext_t * pMqttContext )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus = MQTTSuccess;
    uint8_t publishIndex = MAX_OUTGOING_PUBLISHES;

    assert( pMqttContext != NULL );

    /* Get the next free index for the outgoing publish. All QoS0 outgoing
     * publishes are stored until a PUBREC is received. These messages are
     * stored for supporting a resend if a network connection is broken before
     * receiving a PUBREC. */
    returnStatus = getNextFreeIndexForOutgoingPublishes( &publishIndex );

    if( returnStatus == EXIT_FAILURE )
    {
        log_message( "ERROR", "Unable to find a free spot for outgoing PUBLISH message"  );
    }
    else
    {
        /* This example publishes to only one topic and uses QOS0. */
        outgoingPublishPackets[ publishIndex ].pubInfo.qos = MQTTQoS0;
        outgoingPublishPackets[ publishIndex ].pubInfo.pTopicName = PUBLISH_TOPIC;
        outgoingPublishPackets[ publishIndex ].pubInfo.topicNameLength = PUBLISH_TOPIC_LENGTH;
        outgoingPublishPackets[ publishIndex ].pubInfo.pPayload = MQTT_EXAMPLE_MESSAGE;
        outgoingPublishPackets[ publishIndex ].pubInfo.payloadLength = MQTT_EXAMPLE_MESSAGE_LENGTH;

        /* Get a new packet id. */
        outgoingPublishPackets[ publishIndex ].packetId = MQTT_GetPacketId( pMqttContext );

        /* Send PUBLISH packet. */
        mqttStatus = MQTT_Publish( pMqttContext,
                                   &outgoingPublishPackets[ publishIndex ].pubInfo,
                                   outgoingPublishPackets[ publishIndex ].packetId );

        if( mqttStatus != MQTTSuccess )
        {
           log_message( "ERROR", "Failed to send PUBLISH packet to broker with error = %s",
                        MQTT_Status_strerror( mqttStatus )  );
            cleanupOutgoingPublishAt( publishIndex );
            returnStatus = EXIT_FAILURE;
        }
        else
        {
            log_message( "INFO", "PUBLISH sent for topic %.*s to broker with packet ID %u",
                       PUBLISH_TOPIC_LENGTH,
                       PUBLISH_TOPIC,
                       outgoingPublishPackets[ publishIndex ].packetId  );
        }
    }

    return returnStatus;
}

/*-----------------------------------------------------------*/

static int initializeMqtt( MQTTContext_t * pMqttContext,
                           NetworkContext_t * pNetworkContext )
{
    int returnStatus = EXIT_SUCCESS;
    MQTTStatus_t mqttStatus;
    MQTTFixedBuffer_t networkBuffer;
    TransportInterface_t transport = { NULL };

    assert( pMqttContext != NULL );
    assert( pNetworkContext != NULL );

    /* Fill in TransportInterface send and receive function pointers.
     * For this demo, TCP sockets are used to send and receive data
     * from network. Network context is SSL context for OpenSSL.*/
    transport.pNetworkContext = pNetworkContext;
    transport.send = Openssl_Send;
    transport.recv = Openssl_Recv;
    transport.writev = NULL;

    /* Fill the values for network buffer. */
    networkBuffer.pBuffer = mqttRxBuffer;
    networkBuffer.size = sizeof(mqttRxBuffer);

    /* Initialize MQTT library. */
    mqttStatus = MQTT_Init( pMqttContext,
                            &transport,
                            Clock_GetTimeMs,
                            eventCallback,
                            &networkBuffer );

    if( mqttStatus != MQTTSuccess )
    {
        returnStatus = EXIT_FAILURE;
        log_message( "ERROR", "MQTT_Init failed: Status = %s", MQTT_Status_strerror( mqttStatus )  );
    }
    else
    {
        mqttStatus = MQTT_InitStatefulQoS( pMqttContext,
                                           pOutgoingPublishRecords,
                                           OUTGOING_PUBLISH_RECORD_LEN,
                                           pIncomingPublishRecords,
                                           INCOMING_PUBLISH_RECORD_LEN );

        if( mqttStatus != MQTTSuccess )
        {
            returnStatus = EXIT_FAILURE;
            log_message( "ERROR", "MQTT_InitStatefulQoS failed: Status = %s", MQTT_Status_strerror( mqttStatus )  );
        }
    }

    return returnStatus;
}

/*-----------------------------------------------------------*/

static int subscribePublishLoop( MQTTContext_t * pMqttContext )
{
	int returnStatus = EXIT_SUCCESS;
	MQTTStatus_t mqttStatus = MQTTSuccess;
	uint32_t publishCount = 0;
	const uint32_t maxPublishCount = MQTT_PUBLISH_COUNT_PER_LOOP;

	assert( pMqttContext != NULL );

	if( returnStatus == EXIT_SUCCESS )
	{
		log_message("INFO",  "Subscribing to the MQTT topic %s",g_subscribeTopic  );
		returnStatus = subscribeToTopic( pMqttContext );
	}

	if( returnStatus == EXIT_SUCCESS )
	{
		returnStatus = waitForPacketAck( pMqttContext,
		                         globalSubscribePacketIdentifier,
		                         MQTT_PROCESS_LOOP_TIMEOUT_MS );
	}
	if( ( returnStatus == EXIT_SUCCESS ) && ( globalSubAckStatus == MQTTSubAckFailure ) )
	{
		log_message("INFO",   "Server rejected initial subscription request. Attempting to re-subscribe to topic %.*s",
		   g_subscribeTopic_length,
		   g_subscribeTopic  );
		returnStatus = handleResubscribe( pMqttContext );
	}

	if( returnStatus == EXIT_SUCCESS )
	{
		for( publishCount = 0; publishCount < maxPublishCount; publishCount++ )
		{
	    		log_message("INFO",   "Sending Publish to the MQTT topic %.*s",
		       PUBLISH_TOPIC_LENGTH,
		       PUBLISH_TOPIC  );
	    		returnStatus = publishToTopic( pMqttContext );
	    		mqttStatus = processLoopWithTimeout( pMqttContext, MQTT_PROCESS_LOOP_TIMEOUT_MS );

	    		/* For any error in #MQTT_ProcessLoop, exit the loop and disconnect
	     		* from the broker. */
	    		if( ( mqttStatus != MQTTSuccess ) && ( mqttStatus != MQTTNeedMoreBytes ) )
	    		{
				log_message( "ERROR", "MQTT_ProcessLoop returned with status = %s",
		            		MQTT_Status_strerror( mqttStatus )  );
				returnStatus = EXIT_FAILURE;
				break;
	    		}

	    		log_message("INFO",   "Delay before continuing to next iteration"  );

	    		/* Leave connection idle for some time. */
	    		sleep( DELAY_BETWEEN_PUBLISHES_SECONDS );
		}
	}

	if( returnStatus == EXIT_SUCCESS )
	{
		/* Unsubscribe from the topic. */
		log_message("INFO",  "Unsubscribing from the MQTT topic %.*s",
		   g_subscribeTopic_length,
		   g_subscribeTopic  );
		returnStatus = unsubscribeFromTopic( pMqttContext );
	}

	if( returnStatus == EXIT_SUCCESS )
	{
		/* Process Incoming UNSUBACK packet from the broker. */
		returnStatus = waitForPacketAck( pMqttContext,
		                         globalUnsubscribePacketIdentifier,
		                         MQTT_PROCESS_LOOP_TIMEOUT_MS );
	}

	/* Send an MQTT Disconnect packet over the already connected TCP socket.
	* There is no corresponding response for the disconnect packet. After sending
	* disconnect, client must close the network connection. */
	log_message("INFO",   "Disconnecting the MQTT connection with %.*s",
	       get_broker_endpoint_length(),
	       g_aws_server  );

	if( returnStatus == EXIT_FAILURE )
	{
	/* Returned status is not used to update the local status as there
	 * were failures in demo execution. */
		( void ) disconnectMqttSession( pMqttContext );
	}
	else
	{
		returnStatus = disconnectMqttSession( pMqttContext );
	}

	/* Reset global SUBACK status variable after completion of subscription request cycle. */
	globalSubAckStatus = MQTTSubAckFailure;
	return returnStatus;
}

/*-----------------------------------------------------------*/

static int waitForPacketAck( MQTTContext_t * pMqttContext,
                             uint16_t usPacketIdentifier,
                             uint32_t ulTimeout )
{
	uint32_t ulMqttProcessLoopEntryTime;
	uint32_t ulMqttProcessLoopTimeoutTime;
	uint32_t ulCurrentTime;

	MQTTStatus_t eMqttStatus = MQTTSuccess;
	int returnStatus = EXIT_FAILURE;

	/* Reset the ACK packet identifier being received. */
	globalAckPacketIdentifier = 0U;

	ulCurrentTime = pMqttContext->getTime();
	ulMqttProcessLoopEntryTime = ulCurrentTime;
	ulMqttProcessLoopTimeoutTime = ulCurrentTime + ulTimeout;

	/* Call MQTT_ProcessLoop multiple times until the expected packet ACK
	* is received, a timeout happens, or MQTT_ProcessLoop fails. */
	while( ( globalAckPacketIdentifier != usPacketIdentifier ) &&
	   ( ulCurrentTime < ulMqttProcessLoopTimeoutTime ) &&
	   ( eMqttStatus == MQTTSuccess || eMqttStatus == MQTTNeedMoreBytes ) )
	{
		/* Event callback will set #globalAckPacketIdentifier when receiving
	 	* appropriate packet. */
		eMqttStatus = MQTT_ProcessLoop( pMqttContext );
		ulCurrentTime = pMqttContext->getTime();
	}

	if( ( ( eMqttStatus != MQTTSuccess ) && ( eMqttStatus != MQTTNeedMoreBytes ) ) ||
	( globalAckPacketIdentifier != usPacketIdentifier ) )
	{
		log_message( "ERROR", "MQTT_ProcessLoop failed to receive ACK packet: Expected ACK Packet ID=%02X, LoopDuration=%u, Status=%s",
		    usPacketIdentifier,
		    ( ulCurrentTime - ulMqttProcessLoopEntryTime ),
		    MQTT_Status_strerror( eMqttStatus )  );
	}
	else
	{
		returnStatus = EXIT_SUCCESS;
	}

	return returnStatus;
}

/*-----------------------------------------------------------*/

static MQTTStatus_t processLoopWithTimeout( MQTTContext_t * pMqttContext,
                                            uint32_t ulTimeoutMs )
{
	uint32_t ulMqttProcessLoopTimeoutTime;
	uint32_t ulCurrentTime;

	MQTTStatus_t eMqttStatus = MQTTSuccess;

	ulCurrentTime = pMqttContext->getTime();
	ulMqttProcessLoopTimeoutTime = ulCurrentTime + ulTimeoutMs;

	/* Call MQTT_ProcessLoop multiple times a timeout happens, or
	* MQTT_ProcessLoop fails. */
	while( ( ulCurrentTime < ulMqttProcessLoopTimeoutTime ) &&
	   ( eMqttStatus == MQTTSuccess || eMqttStatus == MQTTNeedMoreBytes ) )
	{
		eMqttStatus = MQTT_ProcessLoop( pMqttContext );
		ulCurrentTime = pMqttContext->getTime();
	}
	return eMqttStatus;
}
static long long now_ms()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000 + tv.tv_usec / 1000;
}
//Monitor for interface Changes
void *thread_interface_monitor(void *arg)
{
    ThreadArgs *args = (ThreadArgs *)arg;
    MQTTContext_t *mqttContext = args->mqttContext;
    const char *imei = args->imei;
    const char *topic = args->topic;

    int sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (sock < 0) {
        log_message("ERROR", "Netlink socket create failed");
        return NULL;
    }

    struct sockaddr_nl sa = {
        .nl_family = AF_NETLINK,
        .nl_groups = RTMGRP_LINK | RTMGRP_IPV4_IFADDR
    };
    bind(sock, (struct sockaddr *)&sa, sizeof(sa));

    char buf[8192];
    struct nlmsghdr *nh;
    long long last_sent = 0;

    while (1)
    {
        ssize_t len = recv(sock, buf, sizeof(buf), 0);
        if (len <= 0) continue;

        for (nh = (struct nlmsghdr *)buf; NLMSG_OK(nh, len);
             nh = NLMSG_NEXT(nh, len))
        {
            if (nh->nlmsg_type == NLMSG_DONE) break;

            // Ignore irrelevant messages
            if (nh->nlmsg_type != RTM_NEWLINK &&
                nh->nlmsg_type != RTM_DELLINK &&
                nh->nlmsg_type != RTM_NEWADDR &&
                nh->nlmsg_type != RTM_DELADDR)
                continue;

            struct ifinfomsg *ifi = NLMSG_DATA(nh);

            // Filter only specific interfaces (important)
            char ifname[IF_NAMESIZE];
            if_indextoname(ifi->ifi_index, ifname);

            if (strcmp(ifname, "eth0") != 0 &&
                strcmp(ifname, "wan") != 0 &&
                strcmp(ifname, "br-lan") != 0)
            {
                // ignore wifi, lo, etc.
                continue;
            }

            // Debounce to avoid repeated firing
            long long now = now_ms();
            if (now - last_sent < DEBOUNCE_MS)
                continue;

            last_sent = now;

            if (mqtt_connected)
            {
                log_message("INFO", "Interface change detected (%s), sending JSON", ifname);
                buildStatusJson(mqttContext, imei, topic);
            }
        }
    }

    close(sock);
    return NULL;
}
//Wifi host change event handler
void *thread_wifi_monitor(void *arg)
{
    ThreadArgs *args = (ThreadArgs *)arg;
    MQTTContext_t *mqttContext = args->mqttContext;
    const char *imei = args->imei;
    const char *topic = args->topic;

    while (1) {
        FILE *fp = popen("iw event -t", "r");
        if (!fp) {
            log_message("ERROR", "Failed to start iw event monitor");
            sleep(10);
            continue;
        }

        log_message("INFO", "Wi-Fi event monitor started using iw");

        int fd = fileno(fp);
        char line[512];

        while (1) {
            fd_set rfds;
            FD_ZERO(&rfds);
            FD_SET(fd, &rfds);

            struct timeval tv = {60, 0};  // 1-minute timeout
            int ret = select(fd + 1, &rfds, NULL, NULL, &tv);

            if (ret > 0 && FD_ISSET(fd, &rfds)) {
                if (!fgets(line, sizeof(line), fp))
                    break;  // EOF or error, restart

                if (strstr(line, "new station") || strstr(line, "del station")) {
                    log_message("INFO", "WiFi event: %s", line);
                    if (mqtt_connected)
                        buildWifiHostsJson(mqttContext, imei, topic);
                }
            } else if (ret == 0) {
                // Timeout: 
                continue;
            } else {
                break;  // select() error, restart iw
            }
        }

        pclose(fp);
        sleep(5);  // brief delay before restarting iw listener
    }

    return NULL;
}
//Ethernet host change event handler
void *thread_ethernet_monitor(void *arg)
{
    char prev_arp[4096] = {0}, curr_arp[4096] = {0}, last_seen_change[4096] = {0};
    time_t change_detected_at = 0, last_sent = 0;

    ThreadArgs *args = (ThreadArgs *)arg;
    MQTTContext_t *mqttContext = args->mqttContext;
    const char *imei = args->imei;
    const char *topic = args->topic;

    while (1) {
        FILE *f = fopen("/proc/net/arp", "r");
        if (f) {
            char line[256];
            curr_arp[0] = '\0';

            while (fgets(line, sizeof(line), f)) {
                if (strstr(line, "IP address")) continue;
                if (strstr(line, "wifi")) continue;
                if (strstr(line, "eth") || strstr(line, "lan"))
                    strncat(curr_arp, line, sizeof(curr_arp) - strlen(curr_arp) - 1);
            }
            fclose(f);
        }

        time_t now = time(NULL);

        // Detect change, but do not send immediately
        if (strcmp(curr_arp, prev_arp) != 0) {
            // if first time seeing this change
            if (strcmp(curr_arp, last_seen_change) != 0) {
                strcpy(last_seen_change, curr_arp);
                change_detected_at = now;
            }

            // Only accept change if stable for long time
            if (difftime(now, change_detected_at) >= STABLE_TIME &&
                difftime(now, last_sent) > 5) 
            {
                log_message("INFO", "Stable Ethernet change detected");
                buildEthernetHostsJson(mqttContext, imei, topic);
                strcpy(prev_arp, curr_arp);
                last_sent = now;
            }
        }

        sleep(1800);
    }

    return NULL;
}

//Periodic Checkin publisher
void *checkin_publisher(void *arg)
{
    ThreadArgs *args = (ThreadArgs *)arg;
    MQTTContext_t *mqttContext = args->mqttContext;
    const char *imei = args->imei;
    const char *topic = args->topic;

    time_t last_checkin = 0;

    while (1)
    {
        if (mqtt_connected)
        {
            time_t now = time(NULL);
            if (difftime(now, last_checkin) >= g_checkin_interval)
            {
                log_message("INFO", "Periodic check-in triggered.");
                buildDataUsageJson(mqttContext, imei, topic);//I Object
                buildGJson(mqttContext, imei, topic);
                buildWifiHostsJson(mqttContext, imei, topic);//D Object
                buildEthernetHostsJson(mqttContext, imei, topic);//T Object
                buildNJson(mqttContext, imei, topic);
                buildOJson(mqttContext, imei, topic);
                buildPJson(mqttContext, imei, topic);
                last_checkin = now;
            }
        }
        sleep(5); // check every few seconds instead of 30 min
    }
    return NULL;
}

void load_mqtt_config(void)
{
    if (!mqtt_config_exists())
    {
        log_message("INFO", "MQTT config file not found — using defaults.");

        pthread_mutex_lock(&mqtt_keepalive_mutex);
        g_mqtt_keepalive = MQTT_KEEP_ALIVE_INTERVAL_SECONDS;
        pthread_mutex_unlock(&mqtt_keepalive_mutex);

        pthread_mutex_lock(&checkin_mutex);
        g_checkin_interval = DEFAULT_CHECKIN;
        pthread_mutex_unlock(&checkin_mutex);

        strncpy(g_aws_server, BROKER_ENDPOINT, sizeof(g_aws_server) - 1);
        strncpy(g_aws_template, PROVISION_TEMPLATE_NAME, sizeof(g_aws_template) - 1);
        return;
    }

    int keepalive = uci_get_int("mqtt.@mqtt[0].keepalive", MQTT_KEEP_ALIVE_INTERVAL_SECONDS);
    int checkin   = uci_get_int("mqtt.@mqtt[0].checkininterval", DEFAULT_CHECKIN);

    pthread_mutex_lock(&mqtt_keepalive_mutex);
    g_mqtt_keepalive = keepalive;
    pthread_mutex_unlock(&mqtt_keepalive_mutex);

    pthread_mutex_lock(&checkin_mutex);
    g_checkin_interval = checkin;
    pthread_mutex_unlock(&checkin_mutex);

    uci_get_string("mqtt.@mqtt[0].server", g_aws_server, sizeof(g_aws_server), BROKER_ENDPOINT);
    uci_get_string("mqtt.@mqtt[0].template", g_aws_template, sizeof(g_aws_template), PROVISION_TEMPLATE_NAME);

    log_message("INFO", "Loaded MQTT config: keepalive=%d sec, checkin=%d sec", keepalive, checkin);
    log_message("INFO", "MQTT server: %s", g_aws_server);
    log_message("INFO", "Provision template: %s", g_aws_template);
}


/*-----------------------------------------------------------*/

int main(int argc, char **argv)
{
    	char imei[64] = { 0 };
    	get_device_imei(imei, sizeof(imei));
    	log_message("INFO", "IMEI:%s", imei);

    	if (strlen(imei) > 10)
    	{
        	snprintf(g_publishTopic, sizeof(g_publishTopic), "%s%s", PUBLISH_TOPIC_BASE, imei);
        	g_publishTopic_length = (uint16_t)strlen(g_publishTopic);
        	log_message("INFO", "Publish topic (Command-Response) = %s", g_publishTopic);
        	snprintf(g_subscribeTopic, sizeof(g_subscribeTopic), "%s%s", SUBSCRIBE_TOPIC_BASE, imei);
        	g_subscribeTopic_length = (uint16_t)strlen(g_subscribeTopic);
        	log_message("INFO", "Subscribe topic = %s", g_subscribeTopic);        	
    	}
    	else
    	{
        	log_message("ERROR", "Failed to get IMEI. Exiting.");
        	return EXIT_FAILURE;
    	}
    	// Build and log client ID
    	buildClientIdentifier();
    	log_message("INFO", "MQTT Client ID = %s", clientIdentifier);
    
    	int returnStatus = EXIT_SUCCESS;
    	MQTTContext_t mqttContext = { 0 };
    	NetworkContext_t networkContext = { 0 };
    	OpensslParams_t opensslParams = { 0 };
    	bool clientSessionPresent = false, brokerSessionPresent = false;

    	networkContext.pParams = &opensslParams;

    	struct timespec tp;
    	(void)clock_gettime(CLOCK_REALTIME, &tp);
    	srand(tp.tv_nsec);

    	char serial[64] = {0};
    	get_device_serial(serial, sizeof(serial));
    	log_message("INFO",  "Device Serial=%s", serial);

	//Load /etc/config/mqtt if exists
	load_mqtt_config();
	//Restore certs from /log if not present in /overlay
	restore_certs_from_log();
	/* Check if device cert already exists */
	if (access(DEVICE_CERT_PATH, R_OK) != 0 || access(DEVICE_KEY_PATH, R_OK) != 0) {
		int returnStatusProv = EXIT_SUCCESS;
		MQTTContext_t mqttContextProv = { 0 };
    		NetworkContext_t networkContextProv = { 0 };
    		OpensslParams_t opensslParamsProv = { 0 };
    		bool clientSessionPresentProv = false, brokerSessionPresentProv = false;
    		networkContextProv.pParams = &opensslParamsProv;
    		/* Initialize MQTT library for usual communication*/
    		returnStatusProv = initializeMqttProv(&mqttContextProv, &networkContextProv);
    		if (returnStatusProv != EXIT_SUCCESS)
    		{
        		log_message("ERROR", "MQTT init failed.");
        		return returnStatusProv;
    		}
    		log_message("INFO", "No device cert/key found, starting provisioning with claim cert...");
        	/* Connect (with retries) */
        	returnStatusProv = connectToServerWithBackoffRetriesProvision(&networkContextProv, &mqttContextProv, &clientSessionPresentProv, &brokerSessionPresentProv);
        	if (returnStatusProv == EXIT_FAILURE)
        	{
            		log_message("ERROR", "Failed to connect with claim certs");
        		return EXIT_FAILURE;
        	}
    		/* Subscribe to cert + provision topics */
    		mqtt_subscribe_topic(&mqttContextProv,CREATE_CERT_ACCEPTED, MQTTQoS1);    		
    		mqtt_subscribe_topic(&mqttContextProv,CREATE_CERT_REJECTED, MQTTQoS1);
		Clock_SleepMs(100); 
    		/* Publish CreateKeysAndCertificate */
    		publish_create_certificate_request(&mqttContextProv);
    		
    		/* Wait for ownership_token.txt to appear, then publish RegisterThing */
    		char *token = NULL;
    		const uint32_t timeoutMs = 200;  //200 ms   		
    		for (int i=0; i<10; i++) {
        		MQTTStatus_t mqttStatus = processLoopWithTimeout(&mqttContextProv, timeoutMs);
        		if (mqttStatus != MQTTSuccess && mqttStatus != MQTTNeedMoreBytes)
			{
    				log_message("ERROR", "MQTT_ProcessLoop returned error=%d (%s)", mqttStatus, MQTT_Status_strerror(mqttStatus));
			}
        		token = read_file("/tmp/ownership_token.txt");
        		if (token) break;
        		usleep(100 * 1000); // 100 ms
    		}

		//waitForOwnershipToken(&mqttContextProv);
        	//token = read_file("/tmp/ownership_token.txt");		
    		    		
    		char provAccepted[256], provRejected[256];
    		snprintf(provAccepted, sizeof(provAccepted), PROVISION_ACCEPTED_FMT, g_aws_template);
    		snprintf(provRejected, sizeof(provRejected), PROVISION_REJECTED_FMT, g_aws_template);
    		mqtt_subscribe_topic(&mqttContextProv, provAccepted, MQTTQoS1);
    		mqtt_subscribe_topic(&mqttContextProv, provRejected, MQTTQoS1);

    		if (token) {
        		log_message("INFO", "Got ownership token, publishing RegisterThing");
        		publish_register_thing(&mqttContextProv, g_aws_template, token, imei, serial);
        		free(token);
    		}

    		/* Run loop until provisioning accepted */
    		for (int i=0; i<20; i++) {
        		MQTTStatus_t mqttStatus = processLoopWithTimeout(&mqttContextProv, timeoutMs);
        		if (mqttStatus != MQTTSuccess && mqttStatus != MQTTNeedMoreBytes)
			{
    				log_message("ERROR", "MQTT_ProcessLoop returned error=%d (%s)", mqttStatus, MQTT_Status_strerror(mqttStatus));
			}       		
        		if (access(DEVICE_CERT_PATH, R_OK)==0 && access(DEVICE_KEY_PATH, R_OK)==0) {
            			log_message("INFO", "Device cert/key saved, provisioning complete");
            			break;
        		}
        		usleep(100 * 1000);
    		}
    		Openssl_Disconnect(&networkContextProv);
	}
	// Perform backup to /log (first time)
	backup_certs_to_log();
	
	//Struct for passing to event handler
	ThreadArgs *args = malloc(sizeof(ThreadArgs));
	args->mqttContext = &mqttContext;
	args->imei = imei;
	args->topic = PUBLISH_TOPIC;
		
    	/* Initialize MQTT library for usual communication*/
    	returnStatus = initializeMqtt(&mqttContext, &networkContext);
    	if (returnStatus != EXIT_SUCCESS)
    	{
        	log_message("ERROR", "MQTT init failed.");
        	return returnStatus;
    	}
	/* Start all three monitoring threads */
	pthread_create(&checkin_thread, NULL, checkin_publisher, args);
	pthread_create(&thread_iface, NULL, thread_interface_monitor, args);
	pthread_create(&thread_wifi, NULL, thread_wifi_monitor, args);
	pthread_create(&thread_eth, NULL, thread_ethernet_monitor, args);	
while (1)
{
    /* Connect (with retries) */
    returnStatus = connectToServerWithBackoffRetries(
        &networkContext, &mqttContext,
        &clientSessionPresent, &brokerSessionPresent, imei);

    if (returnStatus == EXIT_FAILURE)
    {
        log_message("ERROR", "Failed to connect to broker %s", g_aws_server);
        mqtt_connected = false;
        sleep(5);
        continue;
    }

    mqtt_connected = true; // Threads can publish now
    clientSessionPresent = true;

    if (brokerSessionPresent)
    {
        log_message("INFO", "Resuming existing MQTT session.");
        returnStatus = handlePublishResend(&mqttContext);
    }
    else
    {
        log_message("INFO", "Clean MQTT session. Resetting pending publishes.");
        cleanupOutgoingPublishes();
    }

    /* --- Subscribe once --- */
    returnStatus = subscribeToTopic(&mqttContext);
    if (returnStatus != EXIT_SUCCESS)
    {
        log_message("ERROR", "Subscription failed, disconnecting...");
        Openssl_Disconnect(&networkContext);
        sleep(5);
        continue;
    }

    log_message("INFO", "Subscribed to topic: %s", g_subscribeTopic);
    log_message("INFO", "Connected to AWS IoT Core, sending init data...");

    /* One-time messages */
    publishInitJsons(&mqttContext, imei, PUBLISH_TOPIC);

    /* Periodic timer setup */
    time_t lastPeriodic = time(NULL);
    time_t lastPing = time(NULL);
    int loop_fail_count = 0;

    /* --- Persistent MQTT Loop --- */
    while (1)
    {
        MQTTStatus_t mqttStatus = processLoopWithTimeout(&mqttContext, MQTT_PROCESS_LOOP_TIMEOUT_MS);

        if (mqttStatus == MQTTSuccess || mqttStatus == MQTTNeedMoreBytes)
        {
            loop_fail_count = 0; // OK — reset failure counter
        }
        else if (mqttStatus == MQTTPublishDone)
        {
            // Normal publish completion, ignore
            loop_fail_count = 0;
        }
        else if (mqttStatus == MQTTBadParameter || mqttStatus == MQTTIllegalState)
        {
            // Serious client logic/state issue
            log_message("ERROR", "MQTT_ProcessLoop state error (%d). Reconnecting...", mqttStatus);
            Openssl_Disconnect(&networkContext);
            mqtt_connected = false;
            break; // Force reconnect
        }
 	else if (mqttStatus == MQTTRecvFailed)
	{
    		// Not a real error - just no data received within timeout
    		loop_fail_count = 0;
    		continue;
	}       
        else
        {
            // Transient network timeout or socket delay
            log_message("WARN", "MQTT_ProcessLoop transient error (%d), retrying...", mqttStatus);
            loop_fail_count++;
            if (loop_fail_count > 15) // if count exceeds 15, reconnect
            {
                log_message("ERROR", "Too many MQTT loop failures, reconnecting...");
                Openssl_Disconnect(&networkContext);
                mqtt_connected = false;
                break; // reconnect
            }
            usleep(200 * 1000);
            continue;
        }

        /* Check if a command requested reconnect (e.g., keepalive change) */
        if (g_force_mqtt_reconnect)
        {
            log_message("INFO", "Forced MQTT reconnect requested...");
            g_force_mqtt_reconnect = 0;
            Openssl_Disconnect(&networkContext);
            mqtt_connected = false;
            break;
        }

        usleep(100 * 1000); /* small sleep to yield CPU */
    }
}
    	return returnStatus;
}

